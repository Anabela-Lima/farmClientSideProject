package com.example.farm_game;

import com.example.farm_game.models.Crop;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class FarmGameApplicationTests {

	@Test
	void contextLoads() {
	}

}
